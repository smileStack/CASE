require 'test_helper'

class AboutControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
