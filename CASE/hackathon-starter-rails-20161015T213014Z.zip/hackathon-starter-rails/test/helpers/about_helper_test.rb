require 'test_helper'

class AboutHelperTest < ActionView::TestCase
end
